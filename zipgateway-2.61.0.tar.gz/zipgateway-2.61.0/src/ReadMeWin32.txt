You must set the environment variables:
CONTIKI and ZWLIBROOT.


