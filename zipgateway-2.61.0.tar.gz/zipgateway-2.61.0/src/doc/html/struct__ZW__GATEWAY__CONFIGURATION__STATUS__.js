var struct__ZW__GATEWAY__CONFIGURATION__STATUS__ =
[
    [ "cmd", "struct__ZW__GATEWAY__CONFIGURATION__STATUS__.html#a1f45fbf5dfab55f7384138b429a5282b", null ],
    [ "cmdClass", "struct__ZW__GATEWAY__CONFIGURATION__STATUS__.html#a8cad51f6c3014f337f695e5d4eff949b", null ],
    [ "status", "struct__ZW__GATEWAY__CONFIGURATION__STATUS__.html#a72ff69d7ea8466c20193d441f9c58c7d", null ]
];