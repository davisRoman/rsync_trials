var structapplication__nodeinfo__st =
[
    [ "nonSecureCmdCls", "structapplication__nodeinfo__st.html#a329da0b7b021807a73d00d0edbcb6cab", null ],
    [ "nonSecureLen", "structapplication__nodeinfo__st.html#a1917661d2ec57052955d141241d7b5d1", null ],
    [ "secureCmdCls", "structapplication__nodeinfo__st.html#a1350732e811740ea0abaed61453d089a", null ],
    [ "secureLen", "structapplication__nodeinfo__st.html#a5c8f3bc87f19e08a1f1da724ac751783", null ]
];