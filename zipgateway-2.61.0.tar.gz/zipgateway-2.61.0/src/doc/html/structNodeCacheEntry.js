var structNodeCacheEntry =
[
    [ "flags", "structNodeCacheEntry.html#a6997ea7b273bc838f19bcf69e7a8e1b9", null ],
    [ "info_length", "structNodeCacheEntry.html#a392ed40577ad5eaa0f997c3751c0164d", null ],
    [ "last_update", "structNodeCacheEntry.html#a78d716da8565a2ca4de0dbc81221b585", null ],
    [ "node", "structNodeCacheEntry.html#ac2da52d71b43b574fbb3d0501d354efc", null ],
    [ "node_info", "structNodeCacheEntry.html#a2554b3ace2fe081726b39045aa26cb48", null ],
    [ "sec_info", "structNodeCacheEntry.html#a08384bc616f543983949767aac0c9941", null ],
    [ "sec_info_length", "structNodeCacheEntry.html#a00caa2b757cccafe83a7b1c9e11b889e", null ]
];