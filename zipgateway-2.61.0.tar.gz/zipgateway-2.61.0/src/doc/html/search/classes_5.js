var searchData=
[
  ['portal_5fip_5fconfiguration_5fst',['portal_ip_configuration_st',['../structportal__ip__configuration__st.html',1,'']]],
  ['portal_5fip_5fconfiguration_5fwith_5fmagic_5fst',['portal_ip_configuration_with_magic_st',['../structportal__ip__configuration__with__magic__st.html',1,'']]]
];
