var searchData=
[
  ['application_5fnodeinfo_5fst',['application_nodeinfo_st',['../structapplication__nodeinfo__st.html',1,'']]],
  ['application_5fnodeinfo_5fwith_5fmagic_5fst',['application_nodeinfo_with_magic_st',['../structapplication__nodeinfo__with__magic__st.html',1,'']]]
];
