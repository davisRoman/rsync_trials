var searchData=
[
  ['validate_5fdefaultconfig',['validate_defaultconfig',['../group__ZIP__Router.html#gab0073c456bdafa77dc56121703a1e8a3',1,'ZIP_Router.h']]]
];
