var searchData=
[
  ['nat_5ftable_5fentry_5ft',['nat_table_entry_t',['../group__ip46nat.html#gaac4af965c171eb8efb48f6a606ecda9f',1,'ipv46_nat.h']]],
  ['nodecachehdr_5ft',['NodeCacheHdr_t',['../NodeCache_8h.html#a032a6085a61511c16632432f687e78cc',1,'NodeCache.h']]],
  ['nodeid_5ft',['nodeid_t',['../group__ip__emulation.html#gad34a0568c7066643c7dfa68d2650e43b',1,'Bridge.h']]]
];
