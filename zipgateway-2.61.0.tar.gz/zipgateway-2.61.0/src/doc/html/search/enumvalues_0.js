var searchData=
[
  ['auto_5fscheme',['AUTO_SCHEME',['../group__Send__Data__Appl.html#gga07b6522288af6f20d84a075e3cebbd0dae18f8ed37efafcbde859c7be777e9b2a',1,'ZW_SendDataAppl.h']]]
];
