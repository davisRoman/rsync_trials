var searchData=
[
  ['clock_5ftime_5ft',['clock_time_t',['../contiki-conf_8h.html#a42fc7b708ad04499c436158fd5f37ed4',1,'contiki-conf.h']]],
  ['coffee_5fpage_5ft',['coffee_page_t',['../cfs-coffee-arch_8h.html#a0b5048e0b7156298d9da25e2a92183e2',1,'cfs-coffee-arch.h']]]
];
