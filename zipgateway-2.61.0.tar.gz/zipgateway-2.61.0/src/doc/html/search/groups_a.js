var searchData=
[
  ['resource_20directory_20data_20store',['Resource directory data store',['../group__data__store.html',1,'']]],
  ['rime',['Rime',['../group__rime.html',1,'']]]
];
