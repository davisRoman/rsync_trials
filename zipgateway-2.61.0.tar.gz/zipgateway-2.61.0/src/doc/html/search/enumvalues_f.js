var searchData=
[
  ['update_5fstatus_5fnot_5fresponding',['UPDATE_STATUS_NOT_RESPONDING',['../NodeCache_8h.html#a073c3a23fd654a210abcfd324809db12ab28352dcd056952ce8866a192b0327de',1,'NodeCache.h']]],
  ['update_5fstatus_5fok',['UPDATE_STATUS_OK',['../NodeCache_8h.html#a073c3a23fd654a210abcfd324809db12a84312b5161344d13cd643a4ffa50ad29',1,'NodeCache.h']]],
  ['update_5fstatus_5fresource_5funavail',['UPDATE_STATUS_RESOURCE_UNAVAIL',['../NodeCache_8h.html#a073c3a23fd654a210abcfd324809db12a4e2002ee02b5e393a1cb7f011a13d97e',1,'NodeCache.h']]],
  ['update_5fstatus_5funknown',['UPDATE_STATUS_UNKNOWN',['../NodeCache_8h.html#a073c3a23fd654a210abcfd324809db12abc3f046b0504196d45a4a3b56099db7d',1,'NodeCache.h']]],
  ['use_5fcrc16',['USE_CRC16',['../group__Send__Data__Appl.html#gga07b6522288af6f20d84a075e3cebbd0da4778add115f7e6d65c1e21ceafe91ba1',1,'ZW_SendDataAppl.h']]]
];
