var searchData=
[
  ['zip_5fevent_5fall_5fipv4_5fassigned',['ZIP_EVENT_ALL_IPV4_ASSIGNED',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5af735a38aad4e6719cd375b32887ee1aa',1,'router_events.h']]],
  ['zip_5fevent_5fall_5fnodes_5fprobed',['ZIP_EVENT_ALL_NODES_PROBED',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a9dae1205f368675e129530bd52f18c5d',1,'router_events.h']]],
  ['zip_5fevent_5fbridge_5finitialized',['ZIP_EVENT_BRIDGE_INITIALIZED',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a61d77449401abb57175f4a2a4d7b1a15',1,'router_events.h']]],
  ['zip_5fevent_5fnetwork_5fmanagement_5fdone',['ZIP_EVENT_NETWORK_MANAGEMENT_DONE',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5aad42c3ca5f6281e077b9560c8732616d',1,'router_events.h']]],
  ['zip_5fevent_5fnew_5fnetwork',['ZIP_EVENT_NEW_NETWORK',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a1a4116a71abb336b1137e1a20adb02c1',1,'router_events.h']]],
  ['zip_5fevent_5fnm_5fvirt_5fnode_5fremove_5fdone',['ZIP_EVENT_NM_VIRT_NODE_REMOVE_DONE',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a34210e6fe4d3159bea25585a067f9dfe',1,'router_events.h']]],
  ['zip_5fevent_5fnode_5fdhcp_5ftimeout',['ZIP_EVENT_NODE_DHCP_TIMEOUT',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5aa34172a82c71da44ccb65b96376a92c8',1,'router_events.h']]],
  ['zip_5fevent_5fnode_5fipv4_5fassigned',['ZIP_EVENT_NODE_IPV4_ASSIGNED',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a3528656eaaca6f0e4a951f6588b04f90',1,'router_events.h']]],
  ['zip_5fevent_5fqueue_5fupdated',['ZIP_EVENT_QUEUE_UPDATED',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5ac8f2d976a4a7132b80d933f97c5d6687',1,'router_events.h']]],
  ['zip_5fevent_5freset',['ZIP_EVENT_RESET',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5afee6d48560502888621a7940c3cb6a2d',1,'router_events.h']]],
  ['zip_5fevent_5fsend_5fdone',['ZIP_EVENT_SEND_DONE',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5a85be045e7dd40243bd0523853c517fa3',1,'router_events.h']]],
  ['zip_5fevent_5ftunnel_5fready',['ZIP_EVENT_TUNNEL_READY',['../router__events_8h.html#a99fb83031ce9923c84392b4e92f956b5ac5f7ffad95dc421f705324c8cf2c03ec',1,'router_events.h']]]
];
