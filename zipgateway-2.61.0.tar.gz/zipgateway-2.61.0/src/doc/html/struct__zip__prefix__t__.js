var struct__zip__prefix__t__ =
[
    [ "length", "struct__zip__prefix__t__.html#a8f9fe77144d6141bb7761d727e7bbe96", null ],
    [ "prefix", "struct__zip__prefix__t__.html#afc56e3dd2a62e973b7b54326a72ef6eb", null ]
];