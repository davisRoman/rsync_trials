var NAVTREE =
[
  [ "zipgateway", "index.html", [
    [ "Z/IP Gateway User Guide", "index.html", [
      [ "Introduction", "index.html#intro", [
        [ "Overview", "index.html#purpose", null ],
        [ "Audience and prerequisites", "index.html#audience", null ]
      ] ],
      [ "Overall Architecture of Z/IP Gateway", "index.html#arch", null ],
      [ "Compiling Z/IP Gateway", "index.html#build", [
        [ "Set Up Ubuntu x64 for Z/IP Gateway Compilation", "index.html#setupx64", null ],
        [ "Set Up Z/IP Gateway Ubuntu 16.04 LTS Virtual Machine", "index.html#setupvvm", null ],
        [ "Native Build of Z/IP Gateway on Ubuntu", "index.html#zipgw_native", null ],
        [ "Cross-Compiling: Set Up Ubuntu x64 for Target Raspberry Pi (armhf, Linux)", "index.html#setup_rpi", [
          [ "Build Openssl for Raspberry Pi", "index.html#openssl", null ],
          [ "Build Libusb for Raspberry Pi", "index.html#libusb", null ]
        ] ],
        [ "Cross-Compiling: Building Z/IP Gateway for Raspberry Pi", "index.html#zipgw_rpi", null ],
        [ "Cross-Compiling: Set Up Ubuntu x64 for Target Beaglebone (armhf, Linux)", "index.html#setup_bb", null ],
        [ "Cross-compiling:  Building Z/IP Gateway for Beaglebone", "index.html#zipgw_bb", null ]
      ] ],
      [ "Setting up Beaglebone", "index.html#bb", [
        [ "Connecting", "index.html#beagle_conn", null ],
        [ "Copying Z/IP Gateway .deb package to Beaglebone", "index.html#beagle_copy", null ],
        [ "Enable Wireless Cape On Beaglebone", "index.html#Wifi_config", [
          [ "Configure WiFi with Interfaces File", "index.html#wifi_interfaces", null ],
          [ "Configure WiFi with Connman", "index.html#wifi_connman", null ]
        ] ]
      ] ],
      [ "Installing and Launching the Z/IP Gateway.", "index.html#install", [
        [ "Installing Z/IP Gateway .deb package", "index.html#install_deb", null ],
        [ "Configuring Z/IP Gateway", "index.html#config", [
          [ "Manual of Z/IP Gateway configuration variables", "index.html#manual", null ],
          [ "Configuration UI", "index.html#debian_config", null ]
        ] ],
        [ "Starting or Stopping Z/IP Gateway", "index.html#run", null ],
        [ "Verifying Z/IP Gateway Execution", "index.html#verifyzipgwrun", null ],
        [ "Uninstalling Z/IP Gateway", "index.html#uninstall", null ]
      ] ],
      [ "Troubleshooting", "index.html#trouble", [
        [ "No log in /tmp/zipgateway.log", "index.html#no_log", null ],
        [ "Permission files", "index.html#pem", null ],
        [ "zipgateway.tun Permission denied", "index.html#tun", null ],
        [ "Kernel configurations", "index.html#kconfig", null ],
        [ "Wireless", "index.html#Wireless", [
          [ "radvd", "index.html#radvd", null ],
          [ "parprouted", "index.html#parprouted", null ],
          [ "dhcp-helper", "index.html#dhcp_helper", null ],
          [ "udprelay", "index.html#udprelay", null ]
        ] ]
      ] ],
      [ "Pyzip (Z/IP Client)", "index.html#pyzip", [
        [ "Installing on Windows", "index.html#pyzipinstallwin", null ],
        [ "Installing on Ubuntu Linux", "index.html#pyzipinstall", null ],
        [ "Using", "index.html#pyzipusing", [
          [ "Discovering and Connecting", "index.html#discconn", null ],
          [ "Pyzip Toolbar", "index.html#toolbar", null ],
          [ "Adding a node", "index.html#pyzipadd", null ],
          [ "Adding a Security 2 node", "index.html#pyzipadds2", null ],
          [ "Removing a node", "index.html#pyziprem", null ],
          [ "Node specific Network Management", "index.html#nodespecific", null ],
          [ "Sending commands to nodes", "index.html#sendcmd", null ],
          [ "Firmware Update", "index.html#fw", null ]
        ] ],
        [ "Certificate Generation", "index.html#cert_gen", [
          [ "Starting Certificate Generator", "index.html#cert_gen_start", null ],
          [ "Using Certificate Generator", "index.html#cert_gen_use", null ]
        ] ],
        [ "MDNS browser", "index.html#mdns", [
          [ "Installing dependencies on Windows", "index.html#mdnsdepwin", null ],
          [ "Starting MDNS browser on Windows", "index.html#mdnsrunwin", null ],
          [ "Installing dependencies on Ubuntu Linux", "index.html#mdnsdeplin", null ],
          [ "Starting MDNS browser on Linux", "index.html#mdnsrunlin", null ],
          [ "MDNS browswr", "index.html#mdns_win", null ]
        ] ],
        [ "Pyzip Troubleshooting", "index.html#tshoot", null ]
      ] ],
      [ "Miscellanous", "index.html#misc", [
        [ "Unsolicited destination configuration on Windows.", "index.html#miscun", null ],
        [ "Method to move static IP configuration from eth0 to br-lan along with the routes", "index.html#miscnw", null ]
      ] ]
    ] ],
    [ "Deprecated List", "deprecated.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"Bridge_8h.html",
"ZW__classcmd__ex_8h.html#a5f0cb7a9988bd46928203da24f14f892",
"eeprom__layout_8h.html#a18000a2c2c1386c0972c85ddef74f8f5",
"group__NW__CMD__hadler.html#ga95cedf90682ab46f1b9d9a791b8c861a",
"group__ZIP__Resource.html#ga116a0234b360aff78c662ca8da6bdebc",
"group__ZIP__Resource.html#ggaeb134dcfdeb1124196a5309eedaf7b3ba16af1e47ad9347c9783243e96c79ca1e",
"group__ip__emulation.html#ga116fb2788759aaaa6f438833ed1a4a38",
"port_8h.html#a4ee02844b5cb91f1b7d5fb3715fee109",
"struct__ZW__GATEWAY__CONFIGURATION__REPORT__.html",
"zip__router__config_8h.html#a39d947dbedeeffff512d3d118f82d5a5"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';