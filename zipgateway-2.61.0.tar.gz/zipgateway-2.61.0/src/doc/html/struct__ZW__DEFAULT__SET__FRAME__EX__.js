var struct__ZW__DEFAULT__SET__FRAME__EX__ =
[
    [ "cmd", "struct__ZW__DEFAULT__SET__FRAME__EX__.html#a20912ed9894fc0656ac4d69a06a14069", null ],
    [ "cmdClass", "struct__ZW__DEFAULT__SET__FRAME__EX__.html#a0e3cb1ff5154fb2246e3b3d9b22cc5ec", null ],
    [ "seqNo", "struct__ZW__DEFAULT__SET__FRAME__EX__.html#a84dd8400d8f9976382bb4943b2d471d1", null ],
    [ "status", "struct__ZW__DEFAULT__SET__FRAME__EX__.html#a69b46ca94c60f631fc4e19e5be42acbd", null ]
];