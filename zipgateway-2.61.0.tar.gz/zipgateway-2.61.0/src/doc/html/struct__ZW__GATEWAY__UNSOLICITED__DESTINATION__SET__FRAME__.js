var struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__ =
[
    [ "cmd", "struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__.html#a0e907b368c8a74bbca6bc966a329e685", null ],
    [ "cmdClass", "struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__.html#a49d691e5b1b21d7f11dd6b4a6328ac0b", null ],
    [ "unsolicit_ipv6_addr", "struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__.html#aed7ab4516999f324a8223408a1516f34", null ],
    [ "unsolicitPort1", "struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__.html#af103a4d018e275417cf219e3217b1962", null ],
    [ "unsolicitPort2", "struct__ZW__GATEWAY__UNSOLICITED__DESTINATION__SET__FRAME__.html#a03b7d95d5fcb37b51ecdd976b4a43789", null ]
];