var structnat__table__entry =
[
    [ "ip_suffix", "group__ip46nat.html#gadc6b1e9c641c60348623c088c80c4f24", null ],
    [ "nodeid", "group__ip46nat.html#ga3235e92d2d02dcf4cb2db5876f76c290", null ]
];