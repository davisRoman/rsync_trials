var structtx__param =
[
    [ "dendpoint", "group__Send__Data__Appl.html#gad6d0851efc6e11998b26a52011461289", null ],
    [ "dnode", "group__Send__Data__Appl.html#gaf12a23116a684e54f90bb12d3b4021a3", null ],
    [ "rx_flags", "group__Send__Data__Appl.html#ga37cafebb0caf1c81a105ecda2e8f9444", null ],
    [ "scheme", "group__Send__Data__Appl.html#gab899dd3896b6f8d832b20bd9ca95c94e", null ],
    [ "sendpoint", "group__Send__Data__Appl.html#ga26527e935ebe917c8482007e16d5deb1", null ],
    [ "snode", "group__Send__Data__Appl.html#gae5777ccda546145c6f43f1a9cf61661a", null ],
    [ "tx_flags", "group__Send__Data__Appl.html#ga1a6c63321a27e6973b9c5bbc9d55b5da", null ]
];