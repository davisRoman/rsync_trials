#!/bin/bash

#cmake -DOPENSSL_SRC=/home/test/openssl-1.0.1j -DLIBUSB_SRC=/home/test/libusb-1.0.19 -DCMAKE_TOOLCHAIN_FILE=../cmake/Rpi.cmake -DCMAKE_C_COMPILER=/home/test/tools/arm-bcm2708/arm-bcm2708hardfp-linux-gnueabi/bin/arm-bcm2708hardfp-linux-gnueabi-gcc  ..

cmake -DOPENSSL_SRC=/home/davis/timesys/trunk/build_armv7l-timesys-linux-gnueabi/openssl-1.0.1s/openssl-1.0.1s \ 
      -DCMAKE_TOOLCHAIN_FILE=../cmake/Rpi.cmake \
      -DCMAKE_C_COMPILER=/home/davis/timesys/trunk/build_armv7l-timesys-linux-gnueabi/toolchain/bin/armv7l-timesys-linux-gnueabi-gcc  ..
